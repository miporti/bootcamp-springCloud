package com.nttdata.bootcamp.servicioRest.servicioRest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServicioRestApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServicioRestApplication.class, args);
	}

}
