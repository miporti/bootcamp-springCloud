package com.nttdata.bootcamp.micro.demo.Demo.microservicio;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoMicroservicioApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoMicroservicioApplication.class, args);
	}

}
