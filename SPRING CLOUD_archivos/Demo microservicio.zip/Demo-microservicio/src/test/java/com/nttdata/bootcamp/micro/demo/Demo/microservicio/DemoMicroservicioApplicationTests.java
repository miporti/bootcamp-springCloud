package com.nttdata.bootcamp.micro.demo.Demo.microservicio;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoMicroservicioApplicationTests {

	@Test
	void contextLoads() {
	}

}
