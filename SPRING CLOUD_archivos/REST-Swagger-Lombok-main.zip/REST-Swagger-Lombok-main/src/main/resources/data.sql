INSERT INTO clientes ( id, nombre, apellidos, fecha_alta, dni ) VALUES
(1,'Antonio', 'Rodriguez', '2018-01-01', '12345678A'),
(2,'Ana', 'Garcia', '2018-01-01', '12345678B'),
(3,'Pedro', 'Rodriguez', '2018-01-01', '12345678C'),
(4,'María', 'López', '2018-01-01', '12345678D'),
(5,'José', 'Martínez', '2018-01-01', '12345678E'),
(6,'Fernando', 'González', '2018-01-01', '12345678F'),
(7,'Rosa', 'Pérez', '2018-01-01', '12345678G'),
(8,'Francisco', 'Sánchez', '2018-01-01', '12345678H'),
(9,'Carlos', 'Gómez', '2018-01-01', '12345678I'),
(10,'Antonio', 'López', '2018-01-01', '12345678J');
